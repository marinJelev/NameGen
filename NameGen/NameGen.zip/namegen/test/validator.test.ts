import { describe, it, expect } from 'vitest';
import { validateFormat, FORMAT_MESSAGES } from '../src/backend/validator';

describe('validateFormat', () => {
  // ── VALID ──────────────────────────────────────────────────────────────
  it('accepts valid category:object_action', () => {
    expect(validateFormat('checkout:order_completed')).toBeNull();
    expect(validateFormat('signup_flow:pricing_page_viewed')).toBeNull();
    expect(validateFormat('account_settings:password_field_updated')).toBeNull();
    expect(validateFormat('export:report_download_started')).toBeNull();
  });

  it('accepts versioned category', () => {
    expect(validateFormat('checkout_v2:order_completed')).toBeNull();
  });

  // ── TOO_SHORT ──────────────────────────────────────────────────────────
  it('rejects names under 10 chars', () => {
    expect(validateFormat('a:b_c')).toBe('TOO_SHORT');
    expect(validateFormat('')).toBe('TOO_SHORT');
  });

  // ── TOO_LONG ───────────────────────────────────────────────────────────
  it('rejects names over 80 chars', () => {
    const long = 'checkout:' + 'a_'.repeat(40);
    expect(validateFormat(long)).toBe('TOO_LONG');
  });

  // ── MISSING_COLON ──────────────────────────────────────────────────────
  it('rejects names without a colon', () => {
    expect(validateFormat('checkout_order_completed')).toBe('MISSING_COLON');
    expect(validateFormat('checkoutOrderCompleted')).toBe('INVALID_CHARACTERS');
  });

  // ── INVALID_CHARACTERS ─────────────────────────────────────────────────
  it('rejects camelCase', () => {
    expect(validateFormat('checkout:orderCompleted')).toBe('INVALID_CHARACTERS');
  });

  it('rejects hyphens', () => {
    expect(validateFormat('checkout:order-completed')).toBe('INVALID_CHARACTERS');
  });

  it('rejects spaces', () => {
    expect(validateFormat('checkout:order completed')).toBe('INVALID_CHARACTERS');
  });

  it('rejects multiple colons', () => {
    expect(validateFormat('checkout:order:completed')).toBe('INVALID_CHARACTERS');
  });

  // ── MISSING_ACTION_TOKEN ───────────────────────────────────────────────
  it('rejects single token after colon', () => {
    expect(validateFormat('checkout:completed')).toBe('MISSING_ACTION_TOKEN');
  });

  // ── FORMAT_MESSAGES ────────────────────────────────────────────────────
  it('has a message for every error type', () => {
    const errorTypes: NonNullable<ReturnType<typeof validateFormat>>[] = [
      'MISSING_COLON', 'INVALID_SNAKE_CASE', 'TOO_SHORT',
      'TOO_LONG', 'INVALID_CHARACTERS', 'MISSING_ACTION_TOKEN',
    ];
    for (const e of errorTypes) {
      expect(FORMAT_MESSAGES[e]).toBeTruthy();
    }
  });
});
