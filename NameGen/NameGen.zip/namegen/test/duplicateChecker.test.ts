import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock the fetch call to PostHog
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Reset cache between tests by re-importing
beforeEach(() => {
  vi.resetModules();
  mockFetch.mockReset();
});

function mockPostHog(events: string[]) {
  mockFetch.mockResolvedValueOnce({
    ok: true,
    json: async () => ({ results: events.map(name => ({ name })), next: null }),
  });
}

describe('checkOne — duplicate detection', () => {
  it('returns UNIQUE for a new event', async () => {
    mockPostHog(['checkout:order_completed', 'auth:login_failed']);
    const { checkOne } = await import('../src/backend/duplicateChecker');
    const result = await checkOne('export:report_downloaded');
    expect(result.status).toBe('UNIQUE');
  });

  it('returns DUPLICATE for an exact match', async () => {
    mockPostHog(['checkout:order_completed']);
    const { checkOne } = await import('../src/backend/duplicateChecker');
    const result = await checkOne('checkout:order_completed');
    expect(result.status).toBe('DUPLICATE');
    expect(result.matchedEvent).toBe('checkout:order_completed');
  });

  it('returns SIMILAR for a 1-edit distance on a short name (threshold 1)', async () => {
    mockPostHog(['auth:login_failed']);
    const { checkOne } = await import('../src/backend/duplicateChecker');
    // 'auth:login_faild' is distance 1 from 'auth:login_failed' (length 16 < 20 → threshold 1)
    const result = await checkOne('auth:login_faild');
    expect(result.status).toBe('SIMILAR');
    expect(result.matchedEvent).toBe('auth:login_failed');
  });

  it('returns UNIQUE for a 2-edit distance on a short name (threshold 1 — too far)', async () => {
    mockPostHog(['auth:login_failed']);
    const { checkOne } = await import('../src/backend/duplicateChecker');
    // distance 2 on a 16-char name → threshold is 1 → should be UNIQUE
    const result = await checkOne('auth:logon_faild');
    expect(result.status).toBe('UNIQUE');
  });

  it('returns SIMILAR for a 2-edit distance on a medium name (threshold 2)', async () => {
    mockPostHog(['checkout:order_completed']);
    const { checkOne } = await import('../src/backend/duplicateChecker');
    // 'checkout:order_compleated' is distance 1 (length 25, threshold 2)
    const result = await checkOne('checkout:order_compleated');
    expect(result.status).toBe('SIMILAR');
  });
});

describe('checkOne — adaptive threshold boundaries', () => {
  it('uses threshold 1 for names shorter than 20 chars', async () => {
    mockPostHog(['auth:user_loggedin']); // 18 chars
    const { checkOne } = await import('../src/backend/duplicateChecker');
    const result = await checkOne('auth:user_loggedout'); // distance 3 → UNIQUE at threshold 1
    expect(result.status).toBe('UNIQUE');
  });

  it('uses threshold 2 for names 20–39 chars', async () => {
    mockPostHog(['checkout:payment_method_changed']); // 31 chars
    const { checkOne } = await import('../src/backend/duplicateChecker');
    const result = await checkOne('checkout:payment_method_chenged'); // distance 1 → SIMILAR
    expect(result.status).toBe('SIMILAR');
  });
});
