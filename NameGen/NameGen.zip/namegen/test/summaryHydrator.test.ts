import { describe, it, expect, vi } from 'vitest';

// Mock @forge/api before importing the module under test
vi.mock('@forge/api', () => ({
  api: {
    asUser: () => ({
      requestJira: vi.fn().mockResolvedValue({
        ok: true,
        json: async () => ({
          comments: [
            {
              id: 'comment-1',
              body: {
                type: 'doc',
                version: 1,
                content: [
                  {
                    type: 'paragraph',
                    content: [
                      { type: 'text', text: '[NameGen] Event confirmed: ' },
                      { type: 'text', text: 'checkout:order_completed' },
                      { type: 'text', text: " for 'User completes checkout' (AI-generated) — maya@co.com on 2026-03-21" },
                    ],
                  },
                ],
              },
            },
            {
              id: 'comment-2',
              // Non-NameGen comment — should be ignored
              body: {
                type: 'doc', version: 1,
                content: [{ type: 'paragraph', content: [{ type: 'text', text: 'Just a regular comment' }] }],
              },
            },
            {
              id: 'comment-3',
              body: {
                type: 'doc', version: 1,
                content: [
                  {
                    type: 'paragraph',
                    content: [
                      { type: 'text', text: '[NameGen] Event confirmed: ' },
                      { type: 'text', text: 'export:report_downloaded' },
                      { type: 'text', text: " for 'User downloads report' (Custom) — maya@co.com on 2026-03-21" },
                    ],
                  },
                ],
              },
            },
          ],
        }),
      }),
    }),
  },
  route: (strings: TemplateStringsArray, ...values: string[]) =>
    strings.reduce((acc, str, i) => acc + str + (values[i] ?? ''), ''),
}));

describe('hydrateConfirmedEvents', () => {
  it('parses NameGen comments and ignores non-NameGen ones', async () => {
    const { hydrateConfirmedEvents } = await import('../src/backend/summaryHydrator');
    const result = await hydrateConfirmedEvents('PROD-142');
    expect(result).toHaveLength(2);
    expect(result[0].eventName).toBe('checkout:order_completed');
    expect(result[0].origin).toBe('AI-generated');
    expect(result[0].commentId).toBe('comment-1');
    expect(result[1].eventName).toBe('export:report_downloaded');
    expect(result[1].origin).toBe('Custom');
  });

  it('returns empty array when no NameGen comments exist', async () => {
    vi.resetModules();
    vi.mock('@forge/api', () => ({
      api: { asUser: () => ({ requestJira: vi.fn().mockResolvedValue({ ok: true, json: async () => ({ comments: [] }) }) }) },
      route: (s: TemplateStringsArray, ...v: string[]) => s.reduce((a, str, i) => a + str + (v[i] ?? ''), ''),
    }));
    const { hydrateConfirmedEvents } = await import('../src/backend/summaryHydrator');
    const result = await hydrateConfirmedEvents('PROD-999');
    expect(result).toHaveLength(0);
  });
});
