import { describe, it, expect } from 'vitest';
import { getSuggestions, isCanonical, getNearestCanonical } from '../src/backend/autocomplete';

describe('getSuggestions', () => {
  it('returns matching categories for a prefix', () => {
    const results = getSuggestions('check');
    expect(results.map(r => r.name)).toContain('checkout');
  });

  it('returns matching categories for auth prefix', () => {
    const results = getSuggestions('auth');
    expect(results.map(r => r.name)).toContain('auth');
    expect(results.map(r => r.name)).toContain('account_settings');
  });

  it('returns empty array for empty prefix', () => {
    expect(getSuggestions('')).toEqual([]);
  });

  it('returns empty array for no match', () => {
    const results = getSuggestions('zzzzz');
    expect(results).toHaveLength(0);
  });

  it('returns at most 6 suggestions', () => {
    const results = getSuggestions('a'); // matches auth, account_settings, analytics
    expect(results.length).toBeLessThanOrEqual(6);
  });

  it('includes domain and description on each suggestion', () => {
    const results = getSuggestions('checkout');
    expect(results[0]).toHaveProperty('domain');
    expect(results[0]).toHaveProperty('description');
  });
});

describe('isCanonical', () => {
  it('returns true for a known category', () => {
    expect(isCanonical('checkout')).toBe(true);
    expect(isCanonical('signup_flow')).toBe(true);
    expect(isCanonical('export')).toBe(true);
  });

  it('returns false for an unknown category', () => {
    expect(isCanonical('paymnt')).toBe(false);
    expect(isCanonical('chckout')).toBe(false);
  });

  it('is case-insensitive', () => {
    expect(isCanonical('Checkout')).toBe(true);
    expect(isCanonical('EXPORT')).toBe(true);
  });
});

describe('getNearestCanonical', () => {
  it('returns a suggestion for a near-miss', () => {
    const nearest = getNearestCanonical('chk');
    expect(nearest).toBeTruthy();
  });

  it('returns null for a completely unknown prefix', () => {
    const nearest = getNearestCanonical('zzz');
    expect(nearest).toBeNull();
  });
});
