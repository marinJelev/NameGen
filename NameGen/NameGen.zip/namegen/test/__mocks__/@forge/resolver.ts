export default class Resolver {
  private definitions: Record<string, Function> = {};
  define(name: string, fn: Function) { this.definitions[name] = fn; }
  getDefinitions() { return this.definitions; }
}
