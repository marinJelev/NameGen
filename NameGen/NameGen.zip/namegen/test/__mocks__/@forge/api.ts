import { vi } from 'vitest';

export const api = {
  asUser: () => ({
    requestJira: vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({}),
    }),
  }),
};

export const route = (strings: TemplateStringsArray, ...values: string[]) =>
  strings.reduce((acc, str, i) => acc + str + (values[i] ?? ''), '');

export const storage = {
  set: vi.fn().mockResolvedValue(undefined),
  get: vi.fn().mockResolvedValue(null),
};
