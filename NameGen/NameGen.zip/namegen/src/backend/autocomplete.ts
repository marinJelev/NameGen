import type { CategorySuggestion } from '../types';
import CATEGORY_CONFIG from '../../config/categories.json';

export function getSuggestions(prefix: string): CategorySuggestion[] {
  if (!prefix || prefix.length === 0) return [];
  const lower = prefix.toLowerCase().trim();
  return CATEGORY_CONFIG.categories
    .filter(c => c.name.startsWith(lower))
    .slice(0, 6);
}

export function isCanonical(category: string): boolean {
  return CATEGORY_CONFIG.categories.some(
    c => c.name === category.toLowerCase().trim()
  );
}

export function getNearestCanonical(input: string): string | null {
  const lower = input.toLowerCase().trim();
  // Find the closest starting match for the suggestion hint
  const match = CATEGORY_CONFIG.categories.find(c =>
    c.name.startsWith(lower.slice(0, 3))
  );
  return match?.name ?? null;
}
