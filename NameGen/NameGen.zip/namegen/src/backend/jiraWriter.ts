import { api, route } from '@forge/api';
import type { EventOrigin } from '../types';

export async function postConfirmedEvent(
  issueKey:    string,
  eventName:   string,
  actionLabel: string,
  origin:      EventOrigin,
  confirmedBy: string
): Promise<void> {
  const date = new Date().toISOString().split('T')[0];

  // Atlassian Document Format (ADF) body
  const body = {
    body: {
      type: 'doc',
      version: 1,
      content: [
        {
          type: 'paragraph',
          content: [
            { type: 'text', text: '[NameGen] ',      marks: [{ type: 'strong' }] },
            { type: 'text', text: 'Event confirmed: ' },
            { type: 'text', text: eventName,          marks: [{ type: 'code' }] },
            { type: 'text', text: ` for '${actionLabel}' (${origin})` },
            { type: 'text', text: ` — ${confirmedBy} on ${date}` },
          ],
        },
      ],
    },
  };

  const res = await api.asUser().requestJira(
    route`/rest/api/3/issue/${issueKey}/comment`,
    {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    }
  );

  if (!res.ok) {
    throw new Error(`Failed to post Jira comment: ${res.status}`);
  }
}

export async function postSkipNote(
  issueKey: string,
  user: string
): Promise<void> {
  // No comment posted for skips — skip is silent per spec
  // This function is intentionally a no-op
  void issueKey; void user;
}
