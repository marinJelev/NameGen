import { storage } from '@forge/api';
import type { EventOrigin, LogEntry } from '../types';

async function write(key: string, entry: LogEntry): Promise<void> {
  try {
    await storage.set(key, entry);
  } catch (err) {
    // Non-fatal — logging should never break the main flow
    console.error('[NameGen] Instrumentation log failed:', err);
  }
}

export async function logConfirm(
  eventName: string,
  origin: EventOrigin,
  issueKey: string,
  userId: string
): Promise<void> {
  const key = `namegen:log:confirm:${issueKey}:${Date.now()}`;
  await write(key, { type: 'confirm', eventName, origin, issueKey, userId, timestamp: new Date().toISOString() });
}

export async function logSkip(
  issueKey: string,
  userId: string
): Promise<void> {
  const key = `namegen:log:skip:${issueKey}:${Date.now()}`;
  await write(key, { type: 'skip', issueKey, userId, timestamp: new Date().toISOString() });
}

export async function logRegeneration(
  actionLabel: string,
  issueKey: string,
  userId: string
): Promise<void> {
  const key = `namegen:log:regen:${issueKey}:${Date.now()}`;
  await write(key, { type: 'regeneration', actionLabel, issueKey, userId, timestamp: new Date().toISOString() });
}
