import type { FormatError } from '../types';

// Full pattern: category:object_action
// - category: one or more snake_case tokens
// - colon: exactly one separator
// - object_action: two or more snake_case tokens
const FORMAT = /^[a-z][a-z0-9]*(_[a-z0-9]+)*:[a-z][a-z0-9]*(_[a-z0-9]+)+$/;

export function validateFormat(name: string): FormatError {
  if (!name || name.length < 10)                    return 'TOO_SHORT';
  if (name.length > 80)                             return 'TOO_LONG';
  if (!name.includes(':'))                          return 'MISSING_COLON';
  if (/[^a-z0-9_:]/.test(name))                    return 'INVALID_CHARACTERS';
  if ((name.match(/:/g) ?? []).length > 1)          return 'INVALID_CHARACTERS';
  const [category, rest] = name.split(':');
  if (!category || !rest)                           return 'MISSING_COLON';
  const tokens = rest.split('_').filter(Boolean);
  if (tokens.length < 2)                            return 'MISSING_ACTION_TOKEN';
  if (!FORMAT.test(name))                           return 'INVALID_SNAKE_CASE';
  return null;
}

export const FORMAT_MESSAGES: Record<NonNullable<FormatError>, string> = {
  MISSING_COLON:        'Missing category prefix — use format: category:object_action',
  INVALID_SNAKE_CASE:   'Use lowercase letters and underscores only (no spaces, hyphens, or capitals)',
  TOO_SHORT:            'Name is too short — minimum 10 characters',
  TOO_LONG:             'Name is too long — maximum 80 characters',
  INVALID_CHARACTERS:   'Only letters, numbers, underscores, and one colon are allowed',
  MISSING_ACTION_TOKEN: 'The part after the colon needs at least two tokens: object_action',
};
