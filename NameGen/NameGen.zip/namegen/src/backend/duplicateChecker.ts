import type { ActionGroup, ActionGroupWithStatus, Candidate, DuplicateStatus } from '../types';

// Inline Levenshtein — avoids npm dependency issues in Forge sandbox
function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

// Adaptive threshold based on full name length
function adaptiveThreshold(name: string): number {
  const len = name.length;
  if (len < 20) return 1;
  if (len < 40) return 2;
  return 3;
}

// Session cache
let cache: { events: string[]; fetchedAt: number } | null = null;
const TTL_MS = parseInt(process.env['CACHE_TTL_SECONDS'] ?? '300') * 1000;

async function fetchAllPages(): Promise<string[]> {
  const host      = process.env['POSTHOG_HOST'] ?? 'https://app.posthog.com';
  const projectId = process.env['POSTHOG_PROJECT_ID'];
  const apiKey    = process.env['POSTHOG_API_KEY'];

  let url: string | null = `${host}/api/projects/${projectId}/events/?limit=500`;
  const all: string[] = [];

  while (url) {
    const res  = await fetch(url, { headers: { Authorization: `Bearer ${apiKey}` } });
    if (!res.ok) throw new Error(`PostHog API error: ${res.status}`);
    const data = await res.json() as { results: { name: string }[]; next: string | null };
    all.push(...data.results.map(e => e.name));
    url = data.next ?? null;
  }
  return all;
}

export async function getEvents(): Promise<string[]> {
  if (cache && Date.now() - cache.fetchedAt < TTL_MS) return cache.events;
  const events = await fetchAllPages();
  cache = { events, fetchedAt: Date.now() };
  return events;
}

export function invalidateCache(): void {
  cache = null;
}

export async function checkOne(
  name: string
): Promise<{ status: DuplicateStatus; matchedEvent?: string }> {
  const existing  = await getEvents();
  if (existing.includes(name)) return { status: 'DUPLICATE', matchedEvent: name };
  const threshold = adaptiveThreshold(name);
  const similar   = existing.find(e => levenshtein(name, e) <= threshold);
  if (similar) return { status: 'SIMILAR', matchedEvent: similar };
  return { status: 'UNIQUE' };
}

export async function checkAll(
  actions: ActionGroup[]
): Promise<ActionGroupWithStatus[]> {
  const existing = await getEvents();
  return actions.map(action => ({
    ...action,
    candidates: action.candidates.map((name): Candidate => {
      if (existing.includes(name))
        return { name, status: 'DUPLICATE', matchedEvent: name, origin: 'AI-generated' };
      const t       = adaptiveThreshold(name);
      const similar = existing.find(e => levenshtein(name, e) <= t);
      if (similar)
        return { name, status: 'SIMILAR', matchedEvent: similar, origin: 'AI-generated' };
      return { name, status: 'UNIQUE', origin: 'AI-generated' };
    }),
  }));
}
