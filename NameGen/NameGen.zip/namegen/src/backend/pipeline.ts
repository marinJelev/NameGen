import Anthropic from '@anthropic-ai/sdk';
import type { JiraIssue, ActionGroup } from '../types';
import { validateFormat } from './validator';

const anthropic = new Anthropic({ apiKey: process.env['ANTHROPIC_API_KEY'] });

const SYSTEM_PROMPT = `
You are an expert product analytics engineer.
Given a Jira Story ticket, perform two tasks and return a single JSON object.

TASK 1 — Detect all trackable user actions:
Identify every distinct user-facing interaction described or implied in the ticket.
Include both explicit actions (stated in user stories or ACs) and implicit ones
(actions a user would naturally perform to use the feature).
Return an empty actions array for pure backend/infra tickets with no user-facing interactions.

TASK 2 — Generate 5 PostHog event name candidates per detected action.

MANDATORY FORMAT: category:object_action
  category = product area or flow (snake_case)
  object   = the UI element or entity being interacted with (snake_case)
  action   = past-tense verb describing what happened (snake_case)

PREFERRED CATEGORIES (use these for consistency):
  auth, login_flow, signup_flow, account_settings,
  navigation, onboarding, dashboard,
  checkout, cart, payments, orders,
  feed, editor, notifications, search,
  settings, profile, integrations, billing,
  export, reports, analytics

Rules for all names:
  - snake_case throughout — no camelCase, no hyphens, no spaces
  - Past tense for completed user actions (clicked, completed, submitted, viewed, failed)
  - No abbreviations — spell out full words
  - For redesigned flows append version suffix to category: checkout_v2:order_completed
  - The 5 candidates per action must be meaningfully distinct from each other
  - Each name must be between 10 and 80 characters total

Return ONLY valid JSON with no markdown fences or explanation:
{
  "actions": [
    {
      "label": "Short human-readable description of the action",
      "candidates": ["name1", "name2", "name3", "name4", "name5"]
    }
  ]
}
`.trim();

export async function runPipeline(issue: JiraIssue): Promise<ActionGroup[]> {
  const userMessage = [
    `Ticket: ${issue.key}`,
    `Issue Type: ${issue.issueType}`,
    `Title: ${issue.summary}`,
    `Description: ${issue.description?.slice(0, 1000) ?? 'N/A'}`,
    `Labels: ${issue.labels.join(', ') || 'none'}`,
    `Components: ${issue.components.join(', ') || 'none'}`,
  ].join('\n');

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1024,
    system: SYSTEM_PROMPT,
    messages: [{ role: 'user', content: userMessage }],
  });

  const raw  = response.content[0].type === 'text' ? response.content[0].text : '{}';
  const parsed = JSON.parse(raw) as { actions?: ActionGroup[] };

  // Filter out candidates that fail format validation
  const actions = (parsed.actions ?? []).map((a: ActionGroup) => ({
    ...a,
    candidates: a.candidates.filter(c => validateFormat(c) === null),
  })).filter((a: ActionGroup) => a.candidates.length >= 3);

  return actions;
}

export async function regenerate(
  issue: JiraIssue,
  actionLabel: string,
  previousCandidates: string[]
): Promise<string[]> {
  const userMessage = [
    `Ticket: ${issue.key}`,
    `Title: ${issue.summary}`,
    `Description: ${issue.description?.slice(0, 500) ?? 'N/A'}`,
    ``,
    `Generate 5 NEW PostHog event name candidates for this specific action:`,
    `Action: "${actionLabel}"`,
    ``,
    `These names were already suggested — do NOT repeat them:`,
    previousCandidates.map(c => `  - ${c}`).join('\n'),
    ``,
    `At least 3 of the 5 new names must be different from the above list.`,
    `Use the same category:object_action format and rules as before.`,
    `Return ONLY a JSON array of 5 strings, no markdown:`,
    `["name1", "name2", "name3", "name4", "name5"]`,
  ].join('\n');

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 256,
    system: SYSTEM_PROMPT,
    messages: [{ role: 'user', content: userMessage }],
  });

  const raw      = response.content[0].type === 'text' ? response.content[0].text : '[]';
  const names    = JSON.parse(raw) as string[];
  return names.filter(n => validateFormat(n) === null);
}
