import { api, route } from '@forge/api';
import type { ConfirmedEvent, EventOrigin } from '../types';

// Parses: [NameGen] Event confirmed: `{name}` for '{label}' ({origin}) — {user} on {date}
const NAMEGEN_PATTERN =
  /\[NameGen\] Event confirmed: `([^`]+)` for '([^']+)' \(([^)]+)\) — (.+) on (\d{4}-\d{2}-\d{2})/;

function extractPlainText(adfBody: unknown): string {
  if (!adfBody || typeof adfBody !== 'object') return '';
  const body = adfBody as { content?: unknown[] };
  return (body.content ?? [])
    .flatMap((block: unknown) => {
      const b = block as { content?: unknown[] };
      return (b.content ?? []).map((inline: unknown) => {
        const i = inline as { type?: string; text?: string };
        return i.type === 'text' ? (i.text ?? '') : '';
      });
    })
    .join('');
}

export async function hydrateConfirmedEvents(
  issueKey: string
): Promise<ConfirmedEvent[]> {
  const res = await api.asUser().requestJira(
    route`/rest/api/3/issue/${issueKey}/comment?maxResults=100&orderBy=created`,
  );
  const data = await res.json() as { comments?: { id: string; body: unknown }[] };

  const confirmed: ConfirmedEvent[] = [];
  for (const comment of data.comments ?? []) {
    const text  = extractPlainText(comment.body);
    const match = NAMEGEN_PATTERN.exec(text);
    if (!match) continue;
    confirmed.push({
      eventName:   match[1],
      actionLabel: match[2],
      origin:      match[3] as EventOrigin,
      confirmedBy: match[4],
      date:        match[5],
      commentId:   comment.id,
    });
  }
  return confirmed;
}
