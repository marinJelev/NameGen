import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals:     true,
    environment: 'node',
    include:     ['test/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'lcov'],
      include:  ['src/backend/**/*.ts'],
      exclude:  ['src/backend/index.ts'], // Resolver entry not unit-tested directly
    },
  },
  resolve: {
    alias: {
      '@forge/api':      './test/__mocks__/@forge/api.ts',
      '@forge/resolver': './test/__mocks__/@forge/resolver.ts',
    },
  },
});
