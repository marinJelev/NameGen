# NameGen — PostHog Event Name Generator

A Jira-native panel tool that helps Product Managers define PostHog custom events directly from a Jira Story ticket.

NameGen automatically scans every Story, detects all trackable user actions, and generates 5 PostHog-compliant `category:object_action` event name candidates per action — with real-time duplicate checking, category autocomplete, manual edit/create, and Jira comment write-back.

---

## Repository Structure

```
namegen/
├── manifest.yml                  # Atlassian Forge app config
├── config/
│   └── categories.json           # Canonical category list (updatable without redeploy)
├── src/
│   ├── frontend/
│   │   └── index.tsx             # Forge UI Kit 2 React panel
│   ├── backend/
│   │   ├── index.ts              # Forge resolver entry point
│   │   ├── pipeline.ts           # Anthropic API — action detection + name generation
│   │   ├── validator.ts          # Format validation (category:object_action)
│   │   ├── duplicateChecker.ts   # PostHog API + session cache + adaptive fuzzy match
│   │   ├── autocomplete.ts       # Category autocomplete suggestions
│   │   ├── summaryHydrator.ts    # Reads existing NameGen Jira comments for summary
│   │   ├── instrumentationLogger.ts # Logs confirm/skip/regen events to Forge Storage
│   │   └── jiraWriter.ts         # Posts confirmed event comments to Jira
│   └── types/
│       └── index.ts              # Shared TypeScript interfaces
├── test/
│   ├── __mocks__/                # Forge API mocks for testing
│   ├── validator.test.ts
│   ├── duplicateChecker.test.ts
│   ├── autocomplete.test.ts
│   └── summaryHydrator.test.ts
└── prototype/
    └── index.html                # Interactive browser prototype (no dependencies)
```

---

## Prerequisites

- [Atlassian Forge CLI](https://developer.atlassian.com/platform/forge/getting-started/) — `npm install -g @forge/cli`
- Jira Cloud instance
- Anthropic API key
- PostHog project API key (read-only)

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Set environment variables

```bash
forge variables set ANTHROPIC_API_KEY    sk-ant-xxxxx
forge variables set POSTHOG_API_KEY      phx_xxxxx
forge variables set POSTHOG_PROJECT_ID   12345
forge variables set POSTHOG_HOST         https://app.posthog.com
```

### 3. Deploy

```bash
# Development (hot reload)
forge tunnel
forge install --site your-site.atlassian.net

# Production
npm run build
forge deploy
forge install --upgrade
```

---

## Running Tests

```bash
npm test                  # Run all tests
npm run test:coverage     # With coverage report
npm run test:watch        # Watch mode
```

---

## Running the Prototype

Open `prototype/index.html` directly in any browser — no server or dependencies needed.

Or serve it locally:

```bash
cd prototype
node server.js
# Open http://localhost:3000
```

---

## Naming Convention

All events use the official PostHog format: **`category:object_action`**

| Component | Description | Example |
|---|---|---|
| `category` | Product area or flow | `checkout`, `signup_flow`, `export` |
| `object` | UI element or entity | `order_summary`, `format_picker` |
| `action` | Past-tense verb | `completed`, `selected`, `downloaded` |

Full example: `checkout:order_summary_completed`

> **Note:** PostHog events cannot be renamed after creation. See the PRD Section 10 for the rollback and deprecation process.

---

## Documentation

- `docs/NameGen_PRD.docx` — Product Requirements Document (v1.3)
- `docs/NameGen_Technical_Docs.docx` — Technical Documentation (v1.3)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Platform | Atlassian Forge (Node.js 18) |
| Language | TypeScript 5.4 |
| AI Pipeline | Anthropic Claude (claude-sonnet-4-20250514) |
| Duplicate Detection | PostHog REST API + Levenshtein fuzzy match |
| Testing | Vitest |

---

## Availability

The NameGen panel is available on **Jira Story** issue types only (v1). Epic and sub-task availability is planned for v2/v3.
